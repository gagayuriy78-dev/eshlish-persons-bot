# ISHLISH PERSONS

Telegram bot for ISHLISH PERSONS English-language level tests, built with Python, aiogram, and SQLite.

## Setup

Add your Telegram bot token as a Replit Secret named `TEST_TOKEN`.

## Run

```bash
python main.py
```

The bot responds to `/start` with an ISHLISH PERSONS welcome menu for `Oson`, `O'rta`, and
`Murakkab` difficulty levels. Users can then choose `Grammatika` or `Yaqin so'zlar`.
Each difficulty/category combination starts its own question bank. Users can answer
multiple-choice or written questions and receive a final score. The existing A1-C2
quiz engine remains available through `/quiz`.

## Add questions

Questions are imported from `questions.csv` when the bot starts. Existing rows are
not duplicated, so adding new rows works with an existing database. Use this column
order:

```text
level,difficulty,category,question_type,question_text,option_a,option_b,option_c,option_d,correct_answer
```

Legacy A1-C2 questions use `level` and leave `difficulty` and `category` empty.
ISHLISH PERSONS questions use both `difficulty` (`Oson`, `O'rta`, or `Murakkab`) and
`category` (`Grammatika` or `Yaqin so'zlar`) and leave `level` empty. Set
`question_type` to `test` for multiple-choice questions or `write` for written
answers. For `write` questions, leave the four option columns empty.

## Admin panel

Administrators can open the panel with:

```text
/admin
```

The panel provides `📊 Statistika` and `📢 Xabar tarqatish` actions. The configured
administrator ID is `884336506`.

## User accounts and results

The existing SQLite database also stores optional phone/region fields, signup time,
referral relationships, question attempt/failure rates, and completed quiz sessions.
Referral links grant the inviter 50 points once per new user. A certificate image is
sent when a user's cumulative score first reaches 50 points.
